import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-detail',
  templateUrl: './my-detail.component.html',
  styleUrls: ['./my-detail.component.css']
})
export class MyDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

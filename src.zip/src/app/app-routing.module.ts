import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormComponent } from './Basic/form/form.component';
import { MyDetailComponent } from './basic/my-detail/my-detail.component';
import { MyAddressComponent } from './basic/my-address/my-address.component';


const routes: Routes = [
  { path:'', component:FormComponent},
  { path: 'MyDetail', component: MyDetailComponent },
  { path: 'MyAddress', component: MyAddressComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

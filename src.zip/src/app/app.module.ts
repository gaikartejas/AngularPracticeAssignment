import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormComponent } from './Basic/form/form.component';
import { MyDetailComponent } from './basic/my-detail/my-detail.component';
import { MyAddressComponent } from './basic/my-address/my-address.component';
import { Routes, RouterModule } from '@angular/router';

const appRoutes: Routes = [


 
];

@NgModule({
  declarations: [
    AppComponent,
    FormComponent,
    MyDetailComponent,
    MyAddressComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
